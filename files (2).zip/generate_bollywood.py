import pandas as pd
import numpy as np
import random

random.seed(42)
np.random.seed(42)

movies = [
    "Dilwale Dulhania Le Jayenge", "Kuch Kuch Hota Hai", "Kabhi Khushi Kabhie Gham",
    "Devdas", "Kal Ho Naa Ho", "Veer-Zaara", "Bunty Aur Babli", "Rang De Basanti",
    "Dhoom 2", "Om Shanti Om", "Taare Zameen Par", "Jab We Met", "Ghajini",
    "3 Idiots", "Dabangg", "Zindagi Na Milegi Dobara", "Ra.One", "Kahaani",
    "Barfi", "Student Of The Year", "Chennai Express", "Dhoom 3", "PK",
    "Bajrangi Bhaijaan", "Dilwale", "Sultan", "Dangal", "Raees", "Jolly LLB 2",
    "Baahubali 2", "Tiger Zinda Hai", "Padmaavat", "Sanju", "Race 3",
    "Uri", "Gully Boy", "Kabir Singh", "War", "Tanhaji", "Sooryavanshi",
    "RRR", "KGF Chapter 2", "Brahmastra", "Pathaan", "Jawan", "Animal",
    "Dunki", "Fighter", "Stree 2", "Kalki 2898 AD", "Pushpa 2",
    "Mughal-E-Azam", "Sholay", "Dil Chahta Hai", "Lagaan", "Dil Dhadakne Do",
    "Queen", "Andhadhun", "Article 15", "Shershaah", "Bhool Bhulaiyaa 2",
    "Bhediya", "12th Fail", "Fukrey 3", "Munjya", "Crew"
]

actors = [
    "Shah Rukh Khan", "Salman Khan", "Aamir Khan", "Hrithik Roshan",
    "Akshay Kumar", "Ranveer Singh", "Ranbir Kapoor", "Ayushmann Khurrana",
    "Vicky Kaushal", "Tiger Shroff", "Deepika Padukone", "Alia Bhatt",
    "Katrina Kaif", "Priyanka Chopra", "Kareena Kapoor", "Vidya Balan"
]

directors = [
    "Karan Johar", "Rajkumar Hirani", "Rohit Shetty", "Sanjay Leela Bhansali",
    "Zoya Akhtar", "Anurag Kashyap", "Kabir Khan", "SS Rajamouli",
    "Vishnuvardhan", "Aditya Chopra", "Farah Khan", "Imtiaz Ali",
    "Shoojit Sircar", "Vidhu Vinod Chopra", "Aanand L Rai"
]

genres = ["Action", "Romance", "Drama", "Comedy", "Thriller", "Biography", "Fantasy", "Horror"]

rows = []
for i, movie in enumerate(movies):
    year = random.randint(2000, 2024)
    budget = random.randint(10, 350)  # crores
    
    hit_chance = random.random()
    if hit_chance > 0.35:
        collection = budget * random.uniform(1.5, 8.0)
    else:
        collection = budget * random.uniform(0.2, 1.4)
    
    imdb = round(random.uniform(4.5, 9.2), 1)
    
    # Higher rated movies tend to do better
    if imdb > 8.0:
        collection = collection * 1.3
    
    rows.append({
        "movie": movie,
        "year": year,
        "lead_actor": random.choice(actors),
        "director": random.choice(directors),
        "genre": random.choice(genres),
        "budget_cr": round(budget, 1),
        "collection_cr": round(collection, 1),
        "imdb_rating": imdb,
        "verdict": "Hit" if collection > budget * 1.5 else "Flop",
        "release_month": random.choice(["Jan","Feb","Mar","Apr","May","Jun",
                                         "Jul","Aug","Sep","Oct","Nov","Dec"]),
        "screens": random.randint(1500, 6000)
    })

df = pd.DataFrame(rows)
df['roi_percent'] = ((df['collection_cr'] - df['budget_cr']) / df['budget_cr'] * 100).round(1)
df.to_csv("bollywood_data.csv", index=False)
print(f"Dataset ready: {df.shape}")
print(df.head(3))
