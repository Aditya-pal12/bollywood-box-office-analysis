# 📊 AI/ML Jobs Market Analysis — 2023–2025

A data analysis project exploring salary trends, skill demand, experience distribution,
and hiring patterns across 500 AI/ML job postings (2023–2025).

---

## 🎯 Project Objective

To analyze the AI/ML job market and uncover actionable insights for:
- Job seekers targeting high-paying AI roles
- Hiring teams benchmarking salaries
- Professionals planning upskilling

---

## 📁 Project Structure

```
aiml_jobs_project/
│
├── AIML_Jobs_Market_Analysis.xlsx   # Formatted Excel workbook (4 sheets + charts)
├── generate_project.py              # Full Python script (data generation + visuals)
│
├── chart1_salary_by_role.png        # Avg salary by job title
├── chart2_exp_level_donut.png       # Experience level distribution
├── chart3_quarterly_trend.png       # Quarterly job postings trend
├── chart4_worktype_stacked.png      # Work type by role (On-site/Hybrid/Remote)
├── chart5_top_skills.png            # Top 10 in-demand skills
│
└── README.md
```

---

## 📈 Key Insights

| Metric | Finding |
|--------|---------|
| 🏆 Highest Paid Role | AI Researcher (~$195K avg) |
| 🔥 Most In-Demand Skill | Python (appears in 85%+ postings) |
| 💼 Largest Segment | Mid-Level (2–5 yrs) — 38% of all jobs |
| 🌐 Remote Availability | 28% fully remote, 40% hybrid |
| 📅 Fastest Growing Quarter | Q2 2024 — peak posting volume |
| ⏱️ Avg Days to Fill | ~32 days across all roles |

---

## 🛠️ Tools & Technologies

- **Python** — pandas, matplotlib, seaborn, openpyxl
- **Excel** — Pivot tables, formatted sheets, embedded charts
- **Data** — 500 synthetic job records across 10 roles, 11 companies, 9 locations

---

## 📊 Visualizations Preview

### 1. Average Salary by AI/ML Job Title
Horizontal bar chart comparing compensation across 10 roles.

### 2. Experience Level Distribution (Donut)
Breakdown of entry / mid / senior / lead openings.

### 3. Quarterly Job Posting Trend (2023–2025)
Line chart showing AI hiring momentum over 10 quarters.

### 4. Work Type by Role (Stacked Bar)
On-site vs Hybrid vs Remote split for top 5 roles.

### 5. Top 10 In-Demand Skills
Frequency of skills mentioned in job descriptions.

---

## 🚀 How to Run

```bash
# Install dependencies
pip install pandas openpyxl matplotlib seaborn

# Run the script
python generate_project.py
```

All output files (Excel + charts) are generated automatically.

---

## 👤 Author

**Aman** | Freelance AI Trainer & Data Annotator  
Skills: Python · Data Analysis · AI/ML Evaluation · RLHF · NLP · Label Studio
