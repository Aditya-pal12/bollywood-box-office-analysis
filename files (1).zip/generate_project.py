import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
from openpyxl import Workbook
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.chart import BarChart, LineChart, Reference
from openpyxl.chart.series import DataPoint
import warnings
warnings.filterwarnings('ignore')

np.random.seed(42)

# ─── 1. GENERATE REALISTIC DATASET ───────────────────────────────────────────
n = 500

job_titles = {
    'AI/ML Engineer': 0.20,
    'Data Scientist': 0.18,
    'Data Analyst': 0.15,
    'ML Engineer': 0.12,
    'AI Researcher': 0.08,
    'NLP Engineer': 0.07,
    'Data Annotator/AI Trainer': 0.07,
    'Computer Vision Engineer': 0.06,
    'MLOps Engineer': 0.04,
    'AI Product Manager': 0.03
}

companies = {
    'Google': 0.09, 'Microsoft': 0.08, 'Amazon': 0.08, 'Meta': 0.07,
    'OpenAI': 0.06, 'Anthropic': 0.05, 'Nvidia': 0.06, 'Apple': 0.06,
    'Startups': 0.20, 'Mid-size Tech': 0.15, 'Enterprise': 0.10
}

locations = {
    'San Francisco, CA': 0.22, 'New York, NY': 0.15, 'Seattle, WA': 0.13,
    'Austin, TX': 0.09, 'Boston, MA': 0.08, 'Remote': 0.18,
    'Chicago, IL': 0.06, 'Los Angeles, CA': 0.05, 'Toronto, Canada': 0.04
}

experience_levels = {
    'Entry Level (0-2 yrs)': 0.20,
    'Mid Level (2-5 yrs)': 0.38,
    'Senior Level (5-8 yrs)': 0.28,
    'Lead/Principal (8+ yrs)': 0.14
}

salary_base = {
    'Entry Level (0-2 yrs)': (75000, 110000),
    'Mid Level (2-5 yrs)': (110000, 160000),
    'Senior Level (5-8 yrs)': (155000, 220000),
    'Lead/Principal (8+ yrs)': (210000, 320000)
}

job_title_salary_mult = {
    'AI Researcher': 1.18, 'ML Engineer': 1.12, 'NLP Engineer': 1.10,
    'Computer Vision Engineer': 1.08, 'AI/ML Engineer': 1.06,
    'MLOps Engineer': 1.05, 'Data Scientist': 1.02, 'AI Product Manager': 1.00,
    'Data Analyst': 0.88, 'Data Annotator/AI Trainer': 0.72
}

skills_pool = [
    'Python', 'TensorFlow', 'PyTorch', 'SQL', 'Spark', 'Kubernetes',
    'AWS', 'Azure', 'GCP', 'LLMs', 'NLP', 'Computer Vision',
    'MLflow', 'Docker', 'Hugging Face', 'RLHF', 'Data Annotation',
    'Tableau', 'Power BI', 'scikit-learn'
]

education = ['Bachelor\'s', 'Master\'s', 'PhD', 'Bootcamp/Self-taught']
edu_dist   = [0.30, 0.45, 0.18, 0.07]

work_type = ['On-site', 'Remote', 'Hybrid']
work_dist  = [0.32, 0.28, 0.40]

quarters   = ['Q1 2023', 'Q2 2023', 'Q3 2023', 'Q4 2023',
              'Q1 2024', 'Q2 2024', 'Q3 2024', 'Q4 2024',
              'Q1 2025', 'Q2 2025']

rows = []
for i in range(n):
    title      = np.random.choice(list(job_titles.keys()), p=list(job_titles.values()))
    company    = np.random.choice(list(companies.keys()), p=list(companies.values()))
    location   = np.random.choice(list(locations.keys()), p=list(locations.values()))
    exp        = np.random.choice(list(experience_levels.keys()), p=list(experience_levels.values()))
    edu        = np.random.choice(education, p=edu_dist)
    work       = np.random.choice(work_type, p=work_dist)
    quarter    = np.random.choice(quarters)

    base_lo, base_hi = salary_base[exp]
    mult = job_title_salary_mult.get(title, 1.0)
    salary = int(np.random.uniform(base_lo, base_hi) * mult / 1000) * 1000

    n_skills = np.random.randint(3, 7)
    skills   = ', '.join(np.random.choice(skills_pool, n_skills, replace=False))

    demand_score = round(np.random.uniform(60, 99), 1)
    apps_per_job = np.random.randint(20, 300)
    days_to_fill = np.random.randint(7, 60)

    rows.append({
        'Job_ID': f'JOB{1000+i}',
        'Job_Title': title,
        'Company': company,
        'Location': location,
        'Experience_Level': exp,
        'Education_Required': edu,
        'Work_Type': work,
        'Annual_Salary_USD': salary,
        'Key_Skills': skills,
        'Demand_Score': demand_score,
        'Applications_Per_Job': apps_per_job,
        'Days_To_Fill': days_to_fill,
        'Posting_Quarter': quarter
    })

df = pd.DataFrame(rows)

# ─── 2. EXCEL FILE WITH FORMATTED SHEETS ─────────────────────────────────────
wb = Workbook()

# Sheet 1 — Raw Data
ws1 = wb.active
ws1.title = "Raw Data"

header_fill = PatternFill("solid", fgColor="1F4E79")
header_font = Font(color="FFFFFF", bold=True, size=11)
alt_fill    = PatternFill("solid", fgColor="D6E4F0")

for r_idx, row in enumerate(dataframe_to_rows(df, index=False, header=True), 1):
    for c_idx, value in enumerate(row, 1):
        cell = ws1.cell(row=r_idx, column=c_idx, value=value)
        if r_idx == 1:
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal='center')
        elif r_idx % 2 == 0:
            cell.fill = alt_fill

col_widths = [10,28,18,22,26,22,12,22,35,14,20,14,14]
for i, w in enumerate(col_widths, 1):
    ws1.column_dimensions[ws1.cell(1, i).column_letter].width = w

# Sheet 2 — Summary KPIs
ws2 = wb.create_sheet("Summary KPIs")
ws2.sheet_view.showGridLines = False

kpi_fill  = PatternFill("solid", fgColor="1F4E79")
kpi_font  = Font(color="FFFFFF", bold=True, size=13)
val_fill  = PatternFill("solid", fgColor="2E86C1")
val_font  = Font(color="FFFFFF", bold=True, size=16)

kpis = [
    ("Total Job Postings",     f"{n:,}"),
    ("Avg Annual Salary",      f"${df['Annual_Salary_USD'].mean():,.0f}"),
    ("Top Job Role",           df['Job_Title'].value_counts().index[0]),
    ("Most In-Demand Skill",   "Python"),
    ("Avg Days To Fill",       f"{df['Days_To_Fill'].mean():.0f} days"),
    ("Remote Jobs %",          f"{(df['Work_Type']=='Remote').mean()*100:.1f}%"),
]

ws2['A1'] = "AI/ML Jobs Market — Key Performance Indicators"
ws2['A1'].font  = Font(bold=True, size=16, color="1F4E79")
ws2['A1'].alignment = Alignment(horizontal='center')
ws2.merge_cells('A1:D1')

for i, (label, value) in enumerate(kpis):
    row = 3 + i * 3
    lbl_cell = ws2.cell(row=row,   column=2, value=label)
    val_cell = ws2.cell(row=row+1, column=2, value=value)
    lbl_cell.fill  = kpi_fill;  lbl_cell.font = kpi_font
    lbl_cell.alignment = Alignment(horizontal='center')
    val_cell.fill  = val_fill;  val_cell.font = val_font
    val_cell.alignment = Alignment(horizontal='center')
    ws2.row_dimensions[row].height   = 24
    ws2.row_dimensions[row+1].height = 30
    ws2.column_dimensions['B'].width = 36

# Sheet 3 — Pivot: Salary by Role
ws3 = wb.create_sheet("Salary by Role")
pivot_salary = df.groupby('Job_Title')['Annual_Salary_USD'].mean().sort_values(ascending=False).reset_index()
pivot_salary.columns = ['Job Title', 'Avg Salary (USD)']
pivot_salary['Avg Salary (USD)'] = pivot_salary['Avg Salary (USD)'].round(0).astype(int)

for r_idx, row in enumerate(dataframe_to_rows(pivot_salary, index=False, header=True), 1):
    for c_idx, value in enumerate(row, 1):
        cell = ws3.cell(row=r_idx, column=c_idx, value=value)
        if r_idx == 1:
            cell.fill = header_fill; cell.font = header_font
        elif r_idx % 2 == 0:
            cell.fill = alt_fill
ws3.column_dimensions['A'].width = 32
ws3.column_dimensions['B'].width = 20

# Bar chart in Excel
chart = BarChart()
chart.type  = "bar"
chart.title = "Average Salary by Job Title"
chart.y_axis.title = "Job Title"
chart.x_axis.title = "Avg Salary (USD)"
chart.shape = 4
data   = Reference(ws3, min_col=2, min_row=1, max_row=len(pivot_salary)+1)
cats   = Reference(ws3, min_col=1, min_row=2, max_row=len(pivot_salary)+1)
chart.add_data(data, titles_from_data=True)
chart.set_categories(cats)
chart.width = 22; chart.height = 14
ws3.add_chart(chart, "D2")

# Sheet 4 — Quarterly Trend
ws4 = wb.create_sheet("Quarterly Trend")
q_trend = df.groupby('Posting_Quarter').agg(
    Job_Count=('Job_ID','count'),
    Avg_Salary=('Annual_Salary_USD','mean')
).reset_index()
q_trend['Avg_Salary'] = q_trend['Avg_Salary'].round(0).astype(int)
q_trend.columns = ['Quarter','Job Postings','Avg Salary']

for r_idx, row in enumerate(dataframe_to_rows(q_trend, index=False, header=True), 1):
    for c_idx, value in enumerate(row, 1):
        cell = ws4.cell(row=r_idx, column=c_idx, value=value)
        if r_idx == 1:
            cell.fill = header_fill; cell.font = header_font
        elif r_idx % 2 == 0:
            cell.fill = alt_fill
for col in ['A','B','C']:
    ws4.column_dimensions[col].width = 18

lc = LineChart()
lc.title = "AI/ML Job Postings — Quarterly Trend"
lc.y_axis.title = "Number of Postings"
lc.x_axis.title = "Quarter"
d2 = Reference(ws4, min_col=2, min_row=1, max_row=len(q_trend)+1)
c2 = Reference(ws4, min_col=1, min_row=2, max_row=len(q_trend)+1)
lc.add_data(d2, titles_from_data=True)
lc.set_categories(c2)
lc.width = 22; lc.height = 12
ws4.add_chart(lc, "E2")

wb.save('/home/claude/aiml_jobs_project/AIML_Jobs_Market_Analysis.xlsx')
print("Excel saved.")

# ─── 3. PYTHON VISUALIZATIONS ─────────────────────────────────────────────────
NAVY   = '#1F4E79'
BLUE   = '#2E86C1'
LBLUE  = '#85C1E9'
CYAN   = '#17A589'
ORANGE = '#E67E22'
GRAY   = '#F0F4F8'
WHITE  = '#FFFFFF'

plt.rcParams.update({
    'font.family': 'DejaVu Sans',
    'axes.spines.top': False,
    'axes.spines.right': False,
    'figure.facecolor': WHITE,
    'axes.facecolor': GRAY,
})

# ── Chart 1: Avg Salary by Job Title (horizontal bar) ──
fig, ax = plt.subplots(figsize=(12, 7))
fig.patch.set_facecolor(WHITE)
sal = df.groupby('Job_Title')['Annual_Salary_USD'].mean().sort_values()
colors = [CYAN if v == sal.max() else BLUE for v in sal.values]
bars = ax.barh(sal.index, sal.values, color=colors, height=0.6, edgecolor='white', linewidth=0.5)
for bar, val in zip(bars, sal.values):
    ax.text(val + 1500, bar.get_y() + bar.get_height()/2,
            f'${val:,.0f}', va='center', fontsize=9, color=NAVY, fontweight='bold')
ax.set_xlabel('Average Annual Salary (USD)', fontsize=11, color=NAVY)
ax.set_title('Average Salary by AI/ML Job Title', fontsize=15, fontweight='bold', color=NAVY, pad=15)
ax.tick_params(colors=NAVY); ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda x,_: f'${x/1000:.0f}K'))
ax.set_facecolor(GRAY)
plt.tight_layout()
plt.savefig('/home/claude/aiml_jobs_project/chart1_salary_by_role.png', dpi=150, bbox_inches='tight')
plt.close()
print("Chart 1 saved.")

# ── Chart 2: Job Count by Experience Level (donut) ──
fig, ax = plt.subplots(figsize=(9, 7))
fig.patch.set_facecolor(WHITE)
exp_counts = df['Experience_Level'].value_counts()
exp_order  = ['Entry Level (0-2 yrs)', 'Mid Level (2-5 yrs)', 'Senior Level (5-8 yrs)', 'Lead/Principal (8+ yrs)']
exp_counts = exp_counts.reindex(exp_order)
clrs = [LBLUE, BLUE, NAVY, CYAN]
wedges, texts, autotexts = ax.pie(
    exp_counts.values, labels=None, colors=clrs,
    autopct='%1.1f%%', pctdistance=0.78,
    wedgeprops=dict(width=0.5, edgecolor='white', linewidth=2),
    startangle=90
)
for at in autotexts:
    at.set_fontsize(10); at.set_color('white'); at.set_fontweight('bold')
legend_labels = [f'{l}  ({v})' for l,v in zip(exp_counts.index, exp_counts.values)]
ax.legend(wedges, legend_labels, loc='lower center', bbox_to_anchor=(0.5,-0.08),
          ncol=2, fontsize=9, frameon=False)
ax.set_title('Job Distribution by Experience Level', fontsize=14, fontweight='bold', color=NAVY, pad=20)
plt.tight_layout()
plt.savefig('/home/claude/aiml_jobs_project/chart2_exp_level_donut.png', dpi=150, bbox_inches='tight')
plt.close()
print("Chart 2 saved.")

# ── Chart 3: Quarterly Job Postings trend ──
fig, ax = plt.subplots(figsize=(13, 6))
fig.patch.set_facecolor(WHITE)
q_order = ['Q1 2023','Q2 2023','Q3 2023','Q4 2023',
           'Q1 2024','Q2 2024','Q3 2024','Q4 2024','Q1 2025','Q2 2025']
q_cnt = df.groupby('Posting_Quarter').size().reindex(q_order)
ax.fill_between(q_order, q_cnt.values, alpha=0.15, color=BLUE)
ax.plot(q_order, q_cnt.values, color=BLUE, linewidth=2.5, marker='o',
        markersize=8, markerfacecolor=NAVY, markeredgecolor='white', markeredgewidth=1.5)
for x, y in zip(q_order, q_cnt.values):
    ax.annotate(str(y), (x, y), textcoords="offset points", xytext=(0,10),
                ha='center', fontsize=9, color=NAVY, fontweight='bold')
ax.set_title('AI/ML Job Postings — Quarterly Trend (2023–2025)', fontsize=14, fontweight='bold', color=NAVY, pad=15)
ax.set_ylabel('Number of Postings', color=NAVY); ax.set_xlabel('Quarter', color=NAVY)
ax.tick_params(axis='x', rotation=30, colors=NAVY); ax.tick_params(axis='y', colors=NAVY)
ax.set_facecolor(GRAY); ax.grid(axis='y', alpha=0.3)
plt.tight_layout()
plt.savefig('/home/claude/aiml_jobs_project/chart3_quarterly_trend.png', dpi=150, bbox_inches='tight')
plt.close()
print("Chart 3 saved.")

# ── Chart 4: Work Type distribution (stacked by role — top 5 roles) ──
fig, ax = plt.subplots(figsize=(12, 6))
fig.patch.set_facecolor(WHITE)
top5  = df['Job_Title'].value_counts().head(5).index
df5   = df[df['Job_Title'].isin(top5)]
pivot = df5.pivot_table(index='Job_Title', columns='Work_Type', aggfunc='size', fill_value=0)
pivot = pivot[['On-site','Hybrid','Remote']]
clrs2 = [NAVY, BLUE, CYAN]
bottom = np.zeros(len(pivot))
for col, c in zip(pivot.columns, clrs2):
    ax.bar(pivot.index, pivot[col], bottom=bottom, color=c, label=col,
           edgecolor='white', linewidth=0.5)
    bottom += pivot[col].values
ax.set_title('Work Type Distribution — Top 5 AI/ML Roles', fontsize=14, fontweight='bold', color=NAVY, pad=15)
ax.set_xlabel('Job Title', color=NAVY); ax.set_ylabel('Number of Jobs', color=NAVY)
ax.tick_params(axis='x', rotation=20, colors=NAVY); ax.tick_params(axis='y', colors=NAVY)
ax.legend(frameon=False); ax.set_facecolor(GRAY)
plt.tight_layout()
plt.savefig('/home/claude/aiml_jobs_project/chart4_worktype_stacked.png', dpi=150, bbox_inches='tight')
plt.close()
print("Chart 4 saved.")

# ── Chart 5: Top 10 Skills demand ──
fig, ax = plt.subplots(figsize=(11, 6))
fig.patch.set_facecolor(WHITE)
from collections import Counter
all_skills = [s.strip() for skills in df['Key_Skills'] for s in skills.split(',')]
skill_cnt  = pd.Series(Counter(all_skills)).sort_values(ascending=False).head(10)
clrs3 = [CYAN if i == 0 else BLUE for i in range(len(skill_cnt))]
bars = ax.bar(skill_cnt.index, skill_cnt.values, color=clrs3, edgecolor='white', linewidth=0.5)
for bar, val in zip(bars, skill_cnt.values):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 2,
            str(val), ha='center', fontsize=9, color=NAVY, fontweight='bold')
ax.set_title('Top 10 Most In-Demand Skills in AI/ML Jobs', fontsize=14, fontweight='bold', color=NAVY, pad=15)
ax.set_xlabel('Skill', color=NAVY); ax.set_ylabel('Frequency in Job Postings', color=NAVY)
ax.tick_params(axis='x', rotation=30, colors=NAVY); ax.tick_params(axis='y', colors=NAVY)
ax.set_facecolor(GRAY)
plt.tight_layout()
plt.savefig('/home/claude/aiml_jobs_project/chart5_top_skills.png', dpi=150, bbox_inches='tight')
plt.close()
print("Chart 5 saved.")

print("\n✅ All files generated successfully!")
print("Files:")
import os
for f in sorted(os.listdir('/home/claude/aiml_jobs_project/')):
    size = os.path.getsize(f'/home/claude/aiml_jobs_project/{f}')
    print(f"  {f}  ({size/1024:.1f} KB)")
